import java.util.Scanner;
/**
 * 
 * @author Shivam
 *
 */
public class FirstNonRepeatingElement {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		int[] arr = new int[size];
		int[] arr2 = new int[10];
		boolean check = true;
		for (int i = 0; i < size; i++) {
			arr[i] = s.nextInt();
		}

		for (int i = 0; i < size; i++) {
			int num = arr[i];
			arr2[num] += 1;
		}

		for (int i = 0; i < arr2.length; i++) {
			if (arr2[i] == 1) {
				System.out.println(i);
				check = false;
				break;
			}
		}
		if (check == true)
			System.out.println("All elements are repeated");
		s.close();
	}

}
