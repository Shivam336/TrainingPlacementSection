import java.util.Scanner;
/**
 * 
 * @author Shivam
 *
 */
public class Thirdmaximumelementinthearray {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		int[] arr = new int[size];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}
		if (size < 3) {
			System.out.println("Invalid");
		} else {
			boolean isSorted = false;
			int lastUnSortedIndex = size - 1;
			while (isSorted == false) {
				isSorted = true;
				for (int i = 0; i < lastUnSortedIndex; i++) {
					if (arr[i] > arr[i + 1]) {
						int temp = arr[i + 1];
						arr[i + 1] = arr[i];
						arr[i] = temp;
						isSorted = false;
					}
				}
				lastUnSortedIndex--;
			}
			int num = arr[0];
			boolean same = true;
			for (int i = 0; i < size; i++) {
				if (num != arr[i]) {
					same = false;
					break;
				}
			}
			if (same == true) {
				System.out.println("Invalid");
			} else {
				int index = size - 3;
				System.out.println(arr[index]);
			}
			s.close();
		}
	}
}
