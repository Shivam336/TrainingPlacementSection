import java.util.Scanner;
/**
 * 
 * @author Shivam
 *
 */
public class Arrays {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		int[] arr = new int[size];
		for (int i = 0; i < size; i++)
			arr[i] = s.nextInt();

		int roll = s.nextInt();

		if (roll > size) {
			System.out.println("Invalid");
		} else {
			System.out.println(arr[roll]);
		}
		s.close();
	}

}
