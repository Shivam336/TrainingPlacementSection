import java.util.Scanner;
/**
 * 
 * @author Shivam
 *
 */
public class Functions {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		String[] arr = new String[size];
		for (int i = 0; i < size; i++) {
			arr[i] = s.next();
		}
		fizzBuzz(arr);
		s.close();
	}

	static void fizzBuzz(String[] arr) {
		for (int i = 0; i < arr.length; i++) {
			if (Integer.parseInt(arr[i]) % 3 == 0 && Integer.parseInt(arr[i]) % 5 == 0)
				arr[i] = "FizzBuzz";
			else if (Integer.parseInt(arr[i]) % 5 == 0)
				arr[i] = "Buzz";
			else if (Integer.parseInt(arr[i]) % 3 == 0)
				arr[i] = "Fizz";
		}
		for (int i = 0; i < arr.length; i++)
			System.out.print(arr[i] + " ");
	}
}
