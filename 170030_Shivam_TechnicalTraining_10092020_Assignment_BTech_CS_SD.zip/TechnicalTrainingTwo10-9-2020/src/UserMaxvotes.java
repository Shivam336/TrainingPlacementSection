import java.util.Scanner;
/**
 * 
 * @author Shivam
 *
 */
public class UserMaxvotes {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int num = s.nextInt();
		int[] arr = new int[num];
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}
		int max = arr[0];
		int id = 0;
		for (int i = 1; i < arr.length; i++) {
			if (max < arr[i]) {
				max = arr[i];
				id = i;
			}

		}
		System.out.println(id);
		s.close();
	}
}
