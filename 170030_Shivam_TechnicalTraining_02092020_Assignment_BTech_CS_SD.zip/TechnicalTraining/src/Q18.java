import java.util.Scanner;

/**
 * Write a program to calculate the x to the power y without using Standard
 * functions.
 * 
 * @author Shivam
 *
 */
public class Q18 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter x: ");
		int x = s.nextInt();
		System.out.print("Enter y: ");
		int y = s.nextInt();
		int res = x;
		for (int i = 0; i < (y - 1); i++) {
			res = res * x;
		}
		System.out.println(x + " raise to " + y + " = " + res);
		s.close();
	}
}
