import java.util.Scanner;

/**
 * Ques:1 Write A program to accept Four digit number from user and count zero ,
 * odd and even digits from the entered number.
 * 
 * @author Shivam
 *
 */

public class Q1 {
	public static void main(String[] args) {
		System.out.print("Please enter any 4 digit number: ");
		Scanner s = new Scanner(System.in);
		String input = s.next();
		int zeroCount = 0;
		int evenCount = 0;
		int oddCount = 0;
		char[] inputArray = input.toCharArray();
		if (input.length() != 4) {
			System.out.println("Invalid Input");
		} else if (inputArray[0] == '0') {
			System.out.println("Invalid Input");
		} else {
			int num = Integer.parseInt(input);
			while (num > 0) {
				int digit = num % 10;
				if (digit == 0) {
					zeroCount++;
				} else if (digit % 2 == 0)
					evenCount++;
				else
					oddCount++;
				num = num / 10;
			}
			System.out.println("Event Digits are: " + evenCount);
			System.out.println("Odd   Digits are: " + oddCount);
			System.out.println("Zero  Digits are: " + zeroCount);
		}
		s.close();
	}
}
