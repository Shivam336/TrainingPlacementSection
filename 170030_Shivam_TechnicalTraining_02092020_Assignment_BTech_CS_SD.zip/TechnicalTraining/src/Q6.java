import java.util.Scanner;

/**
 * Ques:6 Write a program to accept 5 names from user and store these names into
 * an array sort these array element in alphabetical order.
 * 
 * @author Shivam
 *
 */
public class Q6 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter 5 names:");
		int num = 5;
		String[] array = new String[num];
		for (int i = 0; i < num; i++) {
			System.out.print("Enter " + (i + 1) + " name: ");
			array[i] = s.next();
		}

		System.out.println("Un-sorted names are:");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i].compareTo(array[j]) > 0) {
					String temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}

		System.out.println("Sorted names are:");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		s.close();
	}
}
