import java.util.Scanner;

/**
 * Ques:23 Write a menu driven program to perform the following operations on
 * string using standard library functions --Calculate length of string
 * --Reverse a given string --Concatenation of one string to another --Copy one
 * String into another --Compare two string.
 * 
 * 
 * @author Shivam
 *
 */
public class Q23 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int choice = 0;
		while (choice != 6) {
			System.out.println();
			System.out.println("1.Calculate length of string");
			System.out.println("2.Reverse a given string");
			System.out.println("3.Concatenation of one string to another");
			System.out.println("4.Copy one String into another");
			System.out.println("5.Compare two string.");
			System.out.println("6.Exit");
			System.out.println();
			choice = s.nextInt();
			switch (choice) {
			case 1:
				System.out.print("Enter any string: ");
				String st = s.next();
				System.out.println("Length of " + st + ": " + st.length());
				break;
			case 2:
				System.out.print("Enter any string: ");
				String st2 = s.next();
				StringBuilder sb = new StringBuilder(st2);
				System.out.println("Reverse of " + st2 + ": " + sb.reverse());
				break;
			case 3:
				System.out.print("Enter first string: ");
				String st3 = s.next();
				System.out.print("Enter second string: ");
				String st4 = s.next();
				System.out.println("Concatenate String is: " + st3.concat(st4));
				break;
			case 4:
				System.out.print("Enter any string: ");
				String st5 = s.next();
				char[] cha = st5.toCharArray();
				String st6 = String.copyValueOf(cha);
				System.out.println("Copied String is: " + st6);
				break;
			case 5:
				System.out.print("Enter first string: ");
				String st7 = s.next().toLowerCase();
				System.out.print("Enter second string: ");
				String st8 = s.next().toLowerCase();
				if (st7.compareTo(st8) == 0) {
					System.out.println("Both are same");
				} else if (st7.compareTo(st8) < 0) {
					System.out.println("First string is smaller");
				} else {
					System.out.println("Second string is smaller");
				}
				break;
			case 6:
				System.out.println("Exit");
				System.exit(0);
			}
		}
		s.close();
	}
}
