import java.util.Scanner;

/**
 * Ques:4
 * 
 * Write a program to accept �n� numbers from user , store these numbers into an
 * array and sort the numbers of an array using function.
 * 
 * @author Shivam
 *
 */
public class Q4 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter number of elements: ");
		int numberOfElements = s.nextInt();
		int[] array = new int[numberOfElements];
		for (int i = 0; i < numberOfElements; i++) {
			System.out.print("Enter " + (i + 1) + " element: ");
			array[i] = s.nextInt();
		}
		System.out.println("Un-Sorted Array is: ");
		for (int i = 0; i < numberOfElements; i++) {
			System.out.print(array[i] + " ");
		}
		System.out.println();
		sort(array);
		System.out.println("Sorted Array is: ");
		for (int i = 0; i < numberOfElements; i++) {
			System.out.print(array[i] + " ");
		}
		s.close();
	}

	static void sort(int[] array) {
		boolean isSorted = false;
		int lastUnSortedIndex = array.length - 1;
		while (isSorted == false) {
			isSorted = true;
			for (int i = 0; i < lastUnSortedIndex; i++) {
				if (array[i] > array[i + 1]) {
					int temp = array[i + 1];
					array[i + 1] = array[i];
					array[i] = temp;
					isSorted = false;
				}
			}
			lastUnSortedIndex--;
		}
	}
}
