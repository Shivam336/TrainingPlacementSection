import java.util.Scanner;

/**
 * Ques:10 Write a program to accept a string from user , delete all vowels from
 * the string and display the result.
 * 
 * @author Shivam
 *
 */
public class Q10 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any word: ");
		String input = s.next();
		char[] array = input.toCharArray();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < array.length; i++) {
			if (array[i] == 'a' || array[i] == 'e' || array[i] == 'i' || array[i] == 'o' || array[i] == 'u'
					|| array[i] == 'A' || array[i] == 'E' || array[i] == 'I' || array[i] == 'O' || array[i] == 'U') {
				continue;
			}
			sb.append(array[i]);
		}

		System.out.println("Without vowels: " + sb);
		s.close();
	}
}
