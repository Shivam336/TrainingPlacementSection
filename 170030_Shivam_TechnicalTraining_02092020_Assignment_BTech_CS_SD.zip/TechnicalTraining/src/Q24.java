import java.util.Scanner;

/**
 * Ques:24 Write a program to display the multiplication table of a given
 * number.
 * 
 * @author Shivam
 *
 */
public class Q24 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter table number: ");
		int tableOf = s.nextInt();
		System.out.print("Enter upto Table: ");
		int tableUpTo = s.nextInt();
		StringBuilder sb = new StringBuilder();
		for (int i = 1; i <= tableUpTo; i++) {
			sb.append(String.valueOf(tableOf) + " x " + String.valueOf(i) + " = " + String.valueOf(tableOf * i) + "\n");
		}
		System.out.println(sb);
		s.close();
	}
}
