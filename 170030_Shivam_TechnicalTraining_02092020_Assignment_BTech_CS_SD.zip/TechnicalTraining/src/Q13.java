import java.util.Scanner;

/**
 * Ques:13 Write a program to calculate sum of elements of M*N matrix.
 * 
 * @author Shivam
 *
 */
public class Q13 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter number of row: ");
		int m = s.nextInt();
		System.out.print("Enter number of cols: ");
		int n = s.nextInt();
		int[][] ar = new int[m][n];
		int sum = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print("Enter array[" + (i + 1) + "][" + (j + 1) + "] element: ");
				ar[i][j] = s.nextInt();
				sum += ar[i][j];
			}
		}

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(ar[i][j] + " ");
			}
			System.out.println();
		}

		System.out.println("Sum of elements is: " + sum);
		s.close();

	}
}
