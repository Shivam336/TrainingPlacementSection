import java.util.Scanner;

/**
 * Ques:15 Write a program to calculate X^(Y+Z)
 * 
 * @author Shivam
 *
 */
public class Q15 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter x: ");
		int x = s.nextInt();
		System.out.print("Enter y: ");
		int y = s.nextInt();
		System.out.print("Enter z: ");
		int z = s.nextInt();
		int power = y + z;
		int res = x;
		for (int i = 0; i < power - 1; i++) {
			res = res * x;
		}
		System.out.println(x + " raise to (" + y + " + " + z + ") = " + res);
		s.close();
	}
}
