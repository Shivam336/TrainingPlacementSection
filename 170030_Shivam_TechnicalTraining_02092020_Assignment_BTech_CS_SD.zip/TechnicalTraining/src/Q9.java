import java.util.Scanner;

/**
 * Ques:9 Write a program to calculate the sum of first digit and last digit of
 * a given number
 * 
 * @author Shivam
 *
 */
public class Q9 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any number: ");
		String st = s.next();
		char[] ar = st.toCharArray();
		int first = Integer.parseInt(String.valueOf(ar[0]));
		int last = Integer.parseInt(String.valueOf(ar[ar.length-1]));

		int sum = first + last;
		System.out.println("Sum of first(" + first + ") & last(" + last + ") is: " + sum);
		s.close();
	}
}
