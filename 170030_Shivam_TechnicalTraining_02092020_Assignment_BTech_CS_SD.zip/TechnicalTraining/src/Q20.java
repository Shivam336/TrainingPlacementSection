import java.util.Scanner;

/**
 * Ques:20 Write a program to accept string from the user and replace all
 * occurrences of character �a� by �*� symbol.
 * 
 * @author Shivam
 *
 */
public class Q20 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any word: ");
		String st = s.next();
		char[] ch = st.toCharArray();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == 'a') {
				sb.append("*");
			} else {
				sb.append(ch[i]);
			}
		}
		System.out.println("Final output: " + sb);
		s.close();
	}
}
