import java.util.Scanner;

/**
 * Ques:25 Write a program to display whether the input character is a digit or
 * alphabet.
 * 
 * @author Shivam
 *
 */
public class Q25 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter only one character: ");
		char ch = s.next().charAt(0);
		try {
			int num = Integer.parseInt(String.valueOf(ch));
			System.out.println("This is digit i.e. " + num);
		} catch (Exception e) {
			if (Character.isLetter(ch)) {
				System.out.println("This is alphabet");
			} else {
				System.out.println("Not identify");
			}

		}
		s.close();
	}
}
