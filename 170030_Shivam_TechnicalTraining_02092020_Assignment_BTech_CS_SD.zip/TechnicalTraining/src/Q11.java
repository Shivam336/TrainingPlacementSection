import java.util.Scanner;

/**
 * Ques:11 Write a program to accept a string value from the user and accept a
 * char value from the user and and find out the total occurrence of char value
 * in the string value.
 * 
 * @author Shivam
 *
 */
public class Q11 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any word: ");
		String word = s.next().toLowerCase();
		System.out.print("Enter any char: ");
		char ch = s.next().toLowerCase().charAt(0);
		char[] cha = word.toCharArray();
		int count = 0;
		for (int i = 0; i < cha.length; i++) {
			if (cha[i] == ch)
				count++;
		}
		System.out.println("Count is: " + count);
		s.close();
	}
}
