import java.util.Scanner;

/**
 * Ques:2 Write a program to accept �n� numbers from user , store these numbers
 * into an array. Find out maximum and minimum number from an Array.
 * 
 * @author Shivam
 *
 */
public class Q2 {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter number of elements: ");
		int numOfElement = s.nextInt();
		int[] array = new int[numOfElement];
		for (int i = 0; i < numOfElement; i++) {
			System.out.print("Enter " + (i + 1) + " element: ");
			array[i] = s.nextInt();
		}
		int min = array[0];
		int max = array[0];

		for (int i = 0; i < numOfElement; i++) {
			if (min > array[i]) {
				min = array[i];
			} else if (max < array[i]) {
				max = array[i];
			}
		}
		System.out.println("Minimum element is: " + min);
		System.out.println("Maximum element is: " + max);
		s.close();
	}
}
