import java.util.Scanner;

/**
 * Ques:19 Write a program to accept three sides of a triangle as input and
 * print whether the Trangle is valid or Not. (The trangle is valid, if sum of
 * each of the two sides is greater then the third side.)
 * 
 * @author Shivam
 *
 */
public class Q19 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter first side: ");
		int first = s.nextInt();
		System.out.print("Enter second side: ");
		int second = s.nextInt();
		System.out.print("Enter third side: ");
		int third = s.nextInt();

		if ((first + second) > third || (first + third) > second || (third + second) > first) {
			System.out.println("Valid triangle");
		} else {
			System.out.println("In-valid triangle");
		}
		s.close();

	}
}
