import java.util.Scanner;

/**
 * Ques:7 Write a program to calculate the sum of digits of a given number.
 * 
 * 
 * @author Shivam
 *
 */
public class Q7 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("Enter any number: ");
		int num = s.nextInt();
		if (num < 10) {
			System.out.println("Sum is: " + num);
		} else {
			int sum = 0;
			while (num > 0) {
				int digit = num % 10;
				sum += digit;
				num = num / 10;
			}
			System.out.println("Sum is:" + sum);
		}
		s.close();
	}
}
